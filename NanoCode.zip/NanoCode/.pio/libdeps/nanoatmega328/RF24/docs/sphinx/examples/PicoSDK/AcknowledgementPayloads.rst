acknowledgementPayloads
===========================

.. seealso::
    `defaultPins.h <default_pins.html>`_

.. literalinclude:: ../../../../examples_pico/acknowledgementPayloads.cpp
    :caption: examples_pico/acknowledgementPayloads.cpp
    :linenos:
