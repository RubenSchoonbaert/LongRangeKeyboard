/*
 * Project Long range Keyboard
 * Odisee - IOT-Datacommunication
 * Writen by Ruben Schoonbaert
 * Code for arduino Nano 
 * Platformio Code
 *
 */


#include <Arduino.h>
#include <SPI.h> 
#include <nRF24L01.h>
#include <RF24.h>
#include <Wire.h>

RF24 radio(7, 8);
const byte address[6] = "00001";

void sendKey(int key){
  //Send over I2C (adress 0x08
    Wire.beginTransmission(0x08);
    Wire.write(key); 
    Wire.endTransmission();  
}

void setup() {
  //Start Serial, I2C and SPI 
  Serial.begin(9600);
  Wire.begin();
  Serial.println("starting");
  radio.begin();
  //Initialise NRF24L01 module
  radio.openReadingPipe(0, address);
  radio.setPALevel(RF24_PA_MAX);
  radio.startListening();
  sendKey(4);
}


int getKeyCode(String key) {
  //Only a limited amount of characters are used for this example more could be added here.
  int keyCodes[] = {0, 0, 0, 0, 20, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 51, 17, 18, 19, 4, 21, 22, 23, 24, 25, 29, 27, 28, 26, 30, 31, 16, 33, 34, 35, 36, 37, 38, 39};
  //Special cases
  if (key == "[SPACE]") {
    return 44;
  } else if (key == "[ENTER]") {
    return 40;
  } 
    else if (key == "[BACKSPACE]") {
    return 45;
  } else if (key == "[Del]"){
    return 0x2A;
  } else if (key == "[ESC]"){
    return 0x2A;
  } else {
    char ch = key.charAt(0);
    if (ch >= 'a' && ch <= 'z') {
      return keyCodes[ch-'a'+4];
    } else if (ch >= '0' && ch <= '9') {
      return keyCodes[ch-'0'+30];
    } else {
      return 0;
    }
  }
}

void loop() {
  //If transmission recieved
  if (radio.available()) {
    char text[32] = "";
    radio.read(&text, sizeof(text));
    Serial.println(text);
    int KeyCode = getKeyCode(text);
    sendKey(KeyCode);
  }
}
